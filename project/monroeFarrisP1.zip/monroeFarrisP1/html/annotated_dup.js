var annotated_dup =
[
    [ "framework", "namespaceframework.html", [
      [ "ClassifierAlgorithm", "classframework_1_1_classifier_algorithm.html", "classframework_1_1_classifier_algorithm" ],
      [ "DataSet", "classframework_1_1_data_set.html", "classframework_1_1_data_set" ],
      [ "Experiment", "classframework_1_1_experiment.html", "classframework_1_1_experiment" ],
      [ "kdTreeKNNClassifier", "classframework_1_1kd_tree_k_n_n_classifier.html", null ],
      [ "QualDataSet", "classframework_1_1_qual_data_set.html", null ],
      [ "QuantDataSet", "classframework_1_1_quant_data_set.html", null ],
      [ "simpleKNNClassifier", "classframework_1_1simple_k_n_n_classifier.html", null ],
      [ "TextDataSet", "classframework_1_1_text_data_set.html", null ],
      [ "TimeSeriesDataSet", "classframework_1_1_time_series_data_set.html", null ]
    ] ]
];