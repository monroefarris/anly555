var namespaces_dup =
[
    [ "framework", "namespaceframework.html", "namespaceframework" ],
    [ "test", "namespacetest.html", [
      [ "ca", "namespacetest.html#abb90a96543cab815dc6981d801f80377", null ],
      [ "ds", "namespacetest.html#a8fd1bb93f8b0824d4a171673214ee61d", null ],
      [ "ex", "namespacetest.html#a876d56ae912386e4b8ff777301894847", null ],
      [ "qds", "namespacetest.html#a169e793d21e77ba456fe3ee8fed509ed", null ],
      [ "qualds", "namespacetest.html#ad934df9e50751684d62ff608e1ed18a5", null ],
      [ "skn", "namespacetest.html#a0f2aaad48ec879565b0d057d83e576c2", null ],
      [ "stn", "namespacetest.html#a05a8d9c781d304b5ecb21892ced43160", null ],
      [ "tds", "namespacetest.html#a186bd9db0e2ddbf8c46ef1032dc44c87", null ],
      [ "tsds", "namespacetest.html#aa9ee1d109fa343aebc825c22c0b07983", null ]
    ] ]
];