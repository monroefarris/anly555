var classframework_1_1_classifier_algorithm =
[
    [ "__init__", "classframework_1_1_classifier_algorithm.html#aacd4b56ffd4ed1528f45544dc54b347c", null ],
    [ "test", "classframework_1_1_classifier_algorithm.html#a018787511d93455a62ba63be68387332", null ],
    [ "train", "classframework_1_1_classifier_algorithm.html#a79d144c7fabe0c297a4836dacfea3c60", null ]
];