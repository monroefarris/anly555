var classframework_1_1_data_set =
[
    [ "__init__", "classframework_1_1_data_set.html#a637ef83385c96092f33e3e495e62beb6", null ],
    [ "clean", "classframework_1_1_data_set.html#afeb9d867519e06c182f05cf68294e1d1", null ],
    [ "explore", "classframework_1_1_data_set.html#a387b5b3bb542c9e70450222199cdb661", null ],
    [ "filename", "classframework_1_1_data_set.html#a31ea9141e8291bcedfd64c056e8abb39", null ]
];