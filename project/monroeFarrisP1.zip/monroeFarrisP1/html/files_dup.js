var files_dup =
[
    [ "framework.py", "framework_8py.html", "framework_8py" ],
    [ "test.py", "test_8py.html", "test_8py" ]
];