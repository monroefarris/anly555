var hierarchy =
[
    [ "framework.ClassifierAlgorithm", "classframework_1_1_classifier_algorithm.html", [
      [ "framework.kdTreeKNNClassifier", "classframework_1_1kd_tree_k_n_n_classifier.html", null ],
      [ "framework.simpleKNNClassifier", "classframework_1_1simple_k_n_n_classifier.html", null ]
    ] ],
    [ "framework.DataSet", "classframework_1_1_data_set.html", [
      [ "framework.QualDataSet", "classframework_1_1_qual_data_set.html", null ],
      [ "framework.QuantDataSet", "classframework_1_1_quant_data_set.html", null ],
      [ "framework.TextDataSet", "classframework_1_1_text_data_set.html", null ],
      [ "framework.TimeSeriesDataSet", "classframework_1_1_time_series_data_set.html", null ]
    ] ],
    [ "framework.Experiment", "classframework_1_1_experiment.html", null ]
];