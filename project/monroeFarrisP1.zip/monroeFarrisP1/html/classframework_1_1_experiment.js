var classframework_1_1_experiment =
[
    [ "runCrossVal", "classframework_1_1_experiment.html#a130a54e2ede381313e87d3642274b675", null ],
    [ "score", "classframework_1_1_experiment.html#a5ca4a2ccca251b113e81d08776b1d8c0", null ]
];