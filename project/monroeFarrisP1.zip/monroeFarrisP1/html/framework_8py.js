var framework_8py =
[
    [ "framework.DataSet", "classframework_1_1_data_set.html", "classframework_1_1_data_set" ],
    [ "framework.TimeSeriesDataSet", "classframework_1_1_time_series_data_set.html", null ],
    [ "framework.TextDataSet", "classframework_1_1_text_data_set.html", null ],
    [ "framework.QuantDataSet", "classframework_1_1_quant_data_set.html", null ],
    [ "framework.QualDataSet", "classframework_1_1_qual_data_set.html", null ],
    [ "framework.ClassifierAlgorithm", "classframework_1_1_classifier_algorithm.html", "classframework_1_1_classifier_algorithm" ],
    [ "framework.simpleKNNClassifier", "classframework_1_1simple_k_n_n_classifier.html", null ],
    [ "framework.kdTreeKNNClassifier", "classframework_1_1kd_tree_k_n_n_classifier.html", null ],
    [ "framework.Experiment", "classframework_1_1_experiment.html", "classframework_1_1_experiment" ]
];