var searchData=
[
  ['qualdataset_0',['QualDataSet',['../classframework_1_1_qual_data_set.html',1,'framework']]],
  ['quantdataset_1',['QuantDataSet',['../classframework_1_1_quant_data_set.html',1,'framework']]]
];
