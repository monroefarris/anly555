var searchData=
[
  ['ex_0',['ex',['../namespacetest.html#a876d56ae912386e4b8ff777301894847',1,'test']]]
];
