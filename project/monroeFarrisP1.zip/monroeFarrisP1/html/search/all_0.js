var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classframework_1_1_data_set.html#a637ef83385c96092f33e3e495e62beb6',1,'framework.DataSet.__init__()'],['../classframework_1_1_classifier_algorithm.html#aacd4b56ffd4ed1528f45544dc54b347c',1,'framework.ClassifierAlgorithm.__init__()']]]
];
