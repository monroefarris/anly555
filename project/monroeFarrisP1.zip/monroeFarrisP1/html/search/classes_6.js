var searchData=
[
  ['textdataset_0',['TextDataSet',['../classframework_1_1_text_data_set.html',1,'framework']]],
  ['timeseriesdataset_1',['TimeSeriesDataSet',['../classframework_1_1_time_series_data_set.html',1,'framework']]]
];
