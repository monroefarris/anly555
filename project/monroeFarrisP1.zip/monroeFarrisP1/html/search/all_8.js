var searchData=
[
  ['score_0',['score',['../classframework_1_1_experiment.html#a5ca4a2ccca251b113e81d08776b1d8c0',1,'framework::Experiment']]],
  ['simpleknnclassifier_1',['simpleKNNClassifier',['../classframework_1_1simple_k_n_n_classifier.html',1,'framework']]],
  ['skn_2',['skn',['../namespacetest.html#a0f2aaad48ec879565b0d057d83e576c2',1,'test']]],
  ['stn_3',['stn',['../namespacetest.html#a05a8d9c781d304b5ecb21892ced43160',1,'test']]]
];
