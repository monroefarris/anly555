var searchData=
[
  ['test_0',['test',['../classframework_1_1_classifier_algorithm.html#a018787511d93455a62ba63be68387332',1,'framework::ClassifierAlgorithm']]],
  ['train_1',['train',['../classframework_1_1_classifier_algorithm.html#a79d144c7fabe0c297a4836dacfea3c60',1,'framework::ClassifierAlgorithm']]]
];
