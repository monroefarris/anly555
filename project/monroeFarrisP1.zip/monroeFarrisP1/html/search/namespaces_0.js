var searchData=
[
  ['framework_0',['framework',['../namespaceframework.html',1,'']]]
];
