var searchData=
[
  ['framework_2epy_0',['framework.py',['../framework_8py.html',1,'']]]
];
