var searchData=
[
  ['filename_0',['filename',['../classframework_1_1_data_set.html#a31ea9141e8291bcedfd64c056e8abb39',1,'framework::DataSet']]],
  ['framework_1',['framework',['../namespaceframework.html',1,'']]],
  ['framework_2epy_2',['framework.py',['../framework_8py.html',1,'']]]
];
