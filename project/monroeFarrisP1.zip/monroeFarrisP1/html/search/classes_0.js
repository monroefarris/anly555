var searchData=
[
  ['classifieralgorithm_0',['ClassifierAlgorithm',['../classframework_1_1_classifier_algorithm.html',1,'framework']]]
];
