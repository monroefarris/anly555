var searchData=
[
  ['clean_0',['clean',['../classframework_1_1_data_set.html#afeb9d867519e06c182f05cf68294e1d1',1,'framework::DataSet']]]
];
