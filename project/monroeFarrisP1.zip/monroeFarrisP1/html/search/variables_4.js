var searchData=
[
  ['qds_0',['qds',['../namespacetest.html#a169e793d21e77ba456fe3ee8fed509ed',1,'test']]],
  ['qualds_1',['qualds',['../namespacetest.html#ad934df9e50751684d62ff608e1ed18a5',1,'test']]]
];
