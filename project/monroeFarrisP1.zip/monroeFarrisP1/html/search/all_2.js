var searchData=
[
  ['dataset_0',['DataSet',['../classframework_1_1_data_set.html',1,'framework']]],
  ['ds_1',['ds',['../namespacetest.html#a8fd1bb93f8b0824d4a171673214ee61d',1,'test']]]
];
